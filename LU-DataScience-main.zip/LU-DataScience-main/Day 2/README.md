## Questions - 1:
#### Create an empty list. Accept 10 numbers from the user and append to it the list if it is an even number.

## Questions - 2:
#### Create a notebook on LIST COMPREHENSION. This exercise is to put you in a Self learning mode

## Questions - 3:
#### Given a number n, you have to write a program that generates a dictionary d which contains (i, i*i), where i is from 1 to n (both included).

## Question - 4:
#### Write a program to compute the distance between the current position after a sequence of movement and original point. If the distance is a float, then just print the nearest integer (use round() function for that and then convert it into an integer).
