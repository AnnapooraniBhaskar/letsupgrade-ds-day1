## Question - 1:

#### How to import pandas and check the version?

"import pandas" is importing statement used in python which is used to import the pandas module.

print(pandas.__version __) is used to print the version of the pandas module imported.

## Question - 2

#### How to create a series from a numpy array?

A series can be created from numpy array using 2 different way:

- using only numpy array value
- using only numpy array value along user index value

## Question - 3:

#### How to convert the index of a series into a column of a dataframe?

## Question - 4:

#### Write the code to list all the datasets available in seaborn library.
#### Load the 'mpg' dataset

## Question - 5:

#### Which country origin cars are a part of this dataset?

## Question - 6:

##### Extract the part of the dataframe which contains cars belonging to 'usa'
