## Questions 1:

#### Create a numpy array starting from 2 till 50 with a stepsize of 3.

## Questions 2:

#### Accept two lists of 5 elements each from the user.
#### Convert them to numpy arrays. Concatenate these arrays and print it. Also sort these arrays and print it.

## Questions 3:

#### Write a code snippet to find the dimensions of a ndarray and its size.

## Questions 4:

#### How to convert a 1D array into a 2D array? Demonstrate with the help of a code snippet
####Hint: np.newaxis, np.expand_dims

## Questions 5:

#### Consider two square numpy arrays. Stack them vertically and horizontally.
#### Hint: Use vstack(), hstack()

## Questions 6:

#### How to get unique items and counts of unique items?
