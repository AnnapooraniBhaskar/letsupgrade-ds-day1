Basic conditional statement is explained.
